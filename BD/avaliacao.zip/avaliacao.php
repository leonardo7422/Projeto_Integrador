<?php
echo $_POST["nota"]
?>